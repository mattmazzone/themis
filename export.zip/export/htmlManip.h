#pragma once




void headHtml(std::stringstream *buff);							//dynamic

void preparationHtml(std::stringstream *buff);

void piecesHtml(std::stringstream *buff);							//dynamic	

void consommablesHtml(std::stringstream *buff);							//dynamic

void outilsHtml(std::stringstream *buff);							//dynamic

void pagebreakHtml(std::stringstream *buff);

void checklistHtml(std::stringstream *buff);

void risquesHtml(std::stringstream *buff);

void securiteHtml(std::stringstream *buff);							//dynamic

void tachesHtml(std::stringstream *buff);							//dynamic

void finmaintenanceHtml(std::stringstream *buff);

void notesHtml(std::stringstream *buff);

void badgeHtml(std::stringstream *buff);

void buttonHtml(std::stringstream *buff);

void writeBuffertohtml(std::stringstream *buff);