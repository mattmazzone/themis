#include "menuApp.h"

namespace fs = std::filesystem;

void mainMenu(){
    
    //Terminal App
    int userSelect;
    std::cout << "PM Conversion Tool - Developped by Matteo Mazzone" << std::endl << std::endl;

do {    
    std::cout << "Menu Options: " << std::endl << "   1 - Load a PM.txt file" << std::endl << "   2 - Load a PM.html file" << std::endl << "   3 - Instructions" << std::endl << "   4 - Exit" << std::endl;    
    
    std::cin >> userSelect;
    

    switch (userSelect){
        
        case 1 : 
            std::cout << "You picked 1" << std::endl;
            
            
            selectFile(".txt");
            
            
            break;
        case 2 : 
            std::cout << "You picked 2" << std::endl;
            
            selectFile(".html");
            
            break;
            
        case 3 :
            std::cout << "INSTRUCTIONS" << std::endl;
            break;
            
        case 4 :
            std::cout << "Exit" << std::endl;
            return;
        
        default :
            std::cout << "Invalid" << std::endl;
        
            
        
        
    }
} while (userSelect != 4);


}




void selectFile(std::string extension)
{
    
    std::string path = std::filesystem::current_path();
    for (const auto & entry : std::filesystem::directory_iterator(path)){
        //std::string filePath = std::to_string(entry.path());
        std::u8string path_string{path.u8string()};
        if(path_string.substr(filePath.find_last_of(".") + 1) == "txt") {
            std::cout << entry.path() << std::endl;
        }
    }
    
    

            
        
}




