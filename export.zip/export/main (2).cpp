#include <iostream>
#include <string>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
#include <ctype.h>
#include <vector>
#include <filesystem>


#include "htmlManip.h"
#include "textTransforms.h"
#include "menuApp.h"

int main()
{


    std::stringstream buff;
    std::stringstream *buffPtr;
    buffPtr = &buff;




mainMenu();







/*
    reformatGood();


    headHtml(buffPtr);

    preparationHtml(buffPtr);
    
    piecesHtml(buffPtr);
    
    consommablesHtml(buffPtr);

    writeBuffertohtml(buffPtr);

*/
    //std::cout << buffPtr->rdbuf();








}