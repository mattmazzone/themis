#include <iostream>
#include <string>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
#include <ctype.h>
#include <vector>

#include "htmlManip.h"

#include "textTransforms.h"




void headHtml(std::stringstream *buffer) {


    *buffer << R"_(<!DOCTYPE html>
<html lang=" en ">
<head>
  <title>Hello, world!</title>
  <meta charset=" UTF - 8 " />
  <meta name=" viewport " content=" width = device - width, initial - scale = 1 " />
  <meta name=" description " content=" " />
</head>
<body>)_" << std::endl;

}

void preparationHtml(std::stringstream * buff)
{

    std::vector<std::string> prepStrings;

    std::string input;
    int lineCounter = 1;
    size_t foundPrep;
    size_t foundPrep1;
    size_t foundEnd;

    bool inSection = false;



    std::ifstream inFile("example.txt");
    if (inFile.is_open()) {

        while (getline(inFile, input)) {


            if (inSection) {
                foundEnd = input.find("<<");

                if (foundEnd == std::string::npos) {
                    prepStrings.push_back(input);
                    //*buff << input << std::endl;


                }
                else {
                    inSection = false;
                    inFile.close();
                }
            }
            else {
                input = removeWhitespace(input);

            }

            foundPrep = input.find("<<PREPARATION>>");
            foundPrep1 = input.find("<<PRÉPARATION>>");

            if ((foundPrep != std::string::npos) || (foundPrep1 != std::string::npos)) {
                //Found Prepartion (next line until << is good
                inSection = true;


            }


            lineCounter++;
        }
        inFile.close();
    }
    else {
        std::cout << "Unable to open file";
    }

std::cout << "Preparation (in array):" << std::endl;
    //Check if strings are on right lineCounter
    if (prepStrings.size()==0){
        std::cout << "EMPTY" << std::endl;
    }
    for (auto i: prepStrings)
        std::cout << i << std::endl;






}

void piecesHtml(std::stringstream * buff)
{
    
    std::vector<std::string> piecesStrings;

    std::string input;
    int lineCounter = 1;
    size_t foundPieces;
    size_t foundPieces1;
    size_t foundEnd;

    bool inSection = false;



    std::ifstream inFile("example.txt");
    if (inFile.is_open()) {

        while (getline(inFile, input)) {


            if (inSection) {
                foundEnd = input.find("<<");

                if (foundEnd == std::string::npos) {
                    piecesStrings.push_back(input);
                    //*buff << input << std::endl;


                }
                else {
                    inSection = false;
                    inFile.close();
                }
            }
            else {
                input = removeWhitespace(input);

            }

            foundPieces = input.find("<<PIECES>>");
            foundPieces1 = input.find("<<PIÈCES>>");

            if ((foundPieces != std::string::npos) || (foundPieces1 != std::string::npos)) {
                //Found Prepartion (next line until << is good
                inSection = true;


            }


            lineCounter++;
        }
        inFile.close();
    }
    else {
        std::cout << "Unable to open file";
    }

std::cout << "Pièces (in array):" << std::endl;
    //Check if strings are on right lineCounter
    if (piecesStrings.size()==0){
        std::cout << "EMPTY" << std::endl;
    }
    for (auto i: piecesStrings)
        std::cout << i << std::endl;




}

void consommablesHtml(std::stringstream * buff)
{
        std::vector<std::string> consomStrings;

    std::string input;
    int lineCounter = 1;
    size_t foundConsom;
    size_t foundConsom1;
    size_t foundEnd;

    bool inSection = false;



    std::ifstream inFile("example.txt");
    if (inFile.is_open()) {

        while (getline(inFile, input)) {


            if (inSection) {
                foundEnd = input.find("<<");

                if (foundEnd == std::string::npos) {
                    consomStrings.push_back(input);
                    //*buff << input << std::endl;


                }
                else {
                    inSection = false;
                    inFile.close();
                }
            }
            else {
                input = removeWhitespace(input);

            }

            foundConsom = input.find("<<CONSOMMABLES>>");
            foundConsom1 = input.find("<<CONSOMMABLE>>");

            if ((foundConsom != std::string::npos) || (foundConsom1 != std::string::npos)) {
                //Found Prepartion (next line until << is good
                inSection = true;


            }


            lineCounter++;
        }
        inFile.close();
    }
    else {
        std::cout << "Unable to open file";
    }

std::cout << "Comsom (in array):" << std::endl;
    //Check if strings are on right lineCounter
    if (consomStrings.size()==0){
        std::cout << "EMPTY" << std::endl;
    }
    for (auto i: consomStrings)
        std::cout << i << std::endl;


    
}

void outilsHtml(std::stringstream * buff)
{
}

void pagebreakHtml(std::stringstream * buff)
{
}

void checklistHtml(std::stringstream * buff)
{
}

void risquesHtml(std::stringstream * buff)
{
}

void securiteHtml(std::stringstream * buff)
{
}

void tachesHtml(std::stringstream * buff)
{
}

void finmaintenanceHtml(std::stringstream * buff)
{
}

void notesHtml(std::stringstream * buff)
{
}

void badgeHtml(std::stringstream * buff)
{
}

void buttonHtml(std::stringstream * buff)
{
}

void page1toBuffer(std::stringstream * buff)
{

}




void writeBuffertohtml(std::stringstream *buffer) {

    std::ofstream outFile("output.html");
    if (outFile.is_open()) {

        outFile << buffer->rdbuf();

        outFile.close();
    }
    else {
        std::cout << "Unable to open file";
    }

}