
#include "textTransforms.h"

std::string removeWhitespace(std::string input)
{
    input.erase(std::remove_if(input.begin(), input.end(), ::isspace), input.end());
    return input;
}



std::string onlyString(std::string inp){

    const char* WhiteSpace = " \t\v\r\n";
    size_t start = inp.find_first_not_of(WhiteSpace);
    size_t end = inp.find_last_not_of(WhiteSpace);
    return start == end ? std::string() : inp.substr(start, end - start + 1);
}

std::string sameLine(std::string inp) {
    if (isalpha(inp[0])){

        return inp;
    }
    else{
        return "";
    }
}

void reformatGood(){
    int lineCounter = 1;
    std::string input;
    int totalLines = 0;


    std::stringstream goodFormat;

    std::ifstream inFile("example.txt");

    std::string previous;
    //Get section names and line numbers
    if (inFile.is_open()) {

        while (getline(inFile, input)) {
            
            input = onlyString(input);
            if (!input.empty()){
                goodFormat << onlyString(input) << std::endl;
            }
        }
        inFile.close();
    } else {
        std::cout << "Unable to open file";
    }

    std::ofstream outFile("example.txt");
    if (outFile.is_open()) {
        outFile << goodFormat.rdbuf();
        outFile.close();
    } else {
        std::cout << "Unable to open file";
    }


 std::ifstream inFile1("example.txt");

    
    //Get section names and line numbers
    if (inFile1.is_open()) {

        while (getline(inFile1, input)) {
            input = onlyString(input);
            if ((sameLine(input) == "")&&(lineCounter != 1)){
                goodFormat << std::endl << input;
            }
            else {
                goodFormat << " " << input;
            }
            
            lineCounter++;
        }
        inFile1.close();
    } else {
        std::cout << "Unable to open file";
    }

    std::ofstream outFile1("example.txt");
    if (outFile1.is_open()) {
        outFile1 << goodFormat.rdbuf();
        outFile1.close();
    } else {
        std::cout << "Unable to open file";
    }
    

    bool done = false;

    //Get section names and line numbers
    
     std::ifstream inFile2("example.txt");
    if (inFile2.is_open()) {

        while (getline(inFile2, input)) {
            
            
            if (input.find("( )NE PAS METTRE EN FONCTION SI ÉQUIPEMENT N'EST PAS SÉCURITAIRE") != std::string::npos){
                done = true;
            }
            
            if (!done){
                goodFormat << input << std::endl;
            }
            
        }
        inFile2.close();
    } else {
        std::cout << "Unable to open file";
    }

    std::ofstream outFile2("example.txt");
    if (outFile2.is_open()) {
        outFile2 << goodFormat.rdbuf();
        outFile2.close();
    } else {
        std::cout << "Unable to open file";
    }

}

